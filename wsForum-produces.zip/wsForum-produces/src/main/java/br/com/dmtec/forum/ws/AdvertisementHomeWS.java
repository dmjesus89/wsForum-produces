package br.com.dmtec.forum.ws;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import javax.jws.soap.SOAPBinding.Use;

import br.com.dmtec.forum.dto.request.DeleteAdvertisementHomeRequest;
import br.com.dmtec.forum.dto.request.GetAdvertisementHomeByCriteriaRequest;
import br.com.dmtec.forum.dto.request.GetAdvertisementHomeByIdRequest;
import br.com.dmtec.forum.dto.request.InsertAdvertisementHomeRequest;
import br.com.dmtec.forum.dto.request.UpdateAdvertisementHomeRequest;
import br.com.dmtec.forum.dto.response.DeleteAdvertisementHomeResponse;
import br.com.dmtec.forum.dto.response.GetAdvertisementHomeByCriteriaResponse;
import br.com.dmtec.forum.dto.response.GetAdvertisementHomeByIdResponse;
import br.com.dmtec.forum.dto.response.GetAllAdvertisementHomeResponse;
import br.com.dmtec.forum.dto.response.InsertAdvertisementHomeResponse;
import br.com.dmtec.forum.dto.response.UpdateAdvertisementHomeResponse;

@WebService(name = "AdvertisementHomeWS")
@SOAPBinding(style = Style.RPC, use = Use.LITERAL)
public interface AdvertisementHomeWS {

	@WebMethod(operationName = "insert")
	@WebResult(name = "InsertAdvertisementHomeResponse")
	public InsertAdvertisementHomeResponse insert(
			@WebParam(name = "InsertAdvertisementHomeRequest") InsertAdvertisementHomeRequest insertHomeRequest);

	@WebMethod(operationName = "getById")
	@WebResult(name = "GetAdvertisementHomeByIdResponse")
	public GetAdvertisementHomeByIdResponse getById(
			@WebParam(name = "GetAdvertisementHomeByIdRequest") GetAdvertisementHomeByIdRequest getAdvertisementHomeByIdRequest);

	@WebMethod(operationName = "getAllActive")
	@WebResult(name = "GetAllAdvertisementHomeResponse")
	public GetAllAdvertisementHomeResponse getAllActive();

	@WebMethod(operationName = "update")
	@WebResult(name = "UpdateAdvertisementHomeResponse")
	public UpdateAdvertisementHomeResponse update(
			@WebParam(name = "UpdateAdvertisementHomeRequest") UpdateAdvertisementHomeRequest updateAdvertisementHomeRequest);

	@WebMethod(operationName = "delete")
	@WebResult(name = "DeleteAdvertisementHomeResponse")
	public DeleteAdvertisementHomeResponse delete(
			@WebParam(name = "DeleteAdvertisementHomeRequest") DeleteAdvertisementHomeRequest deleteAdvertisementHomeRequest);

	@WebMethod(operationName = "getByCriteria")
	@WebResult(name = "GetAdvertisementHomeByCriteriaResponse")
	public GetAdvertisementHomeByCriteriaResponse getByCriteria(
			@WebParam(name = "GetAdvertisementHomeByCriteriaRequest") GetAdvertisementHomeByCriteriaRequest getAdvertisementHomeByCriteriaRequest);

}
