package br.com.dmtec.forum.service;

import java.util.List;

import br.com.dmtec.forum.dao.TopicDAOImpl;
import br.com.dmtec.forum.dto.TopicDTO;

public class TopicService {

	public static boolean insertTopic(TopicDTO topic) {
		return TopicDAOImpl.insertTopic(topic);
	}

	public static TopicDTO getTopicById(long id) {
		return TopicDAOImpl.getTopicById(id);
	}

	public static List<TopicDTO> getTopicByCriteria(TopicDTO topic) {
		return TopicDAOImpl.getTopicByCriteria(topic);
	}

	public static List<TopicDTO> getAllTopic() {
		return TopicDAOImpl.getAllTopic();
	}

}
