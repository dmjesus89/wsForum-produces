package br.com.dmtec.forum.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "PhoneDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class PhoneDTO {

	@XmlElement(name = "id", required = true)
	private int id;

	@XmlElement(name = "number", required = true)
	private String number;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

}
