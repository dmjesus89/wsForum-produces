package br.com.dmtec.forum.dto.response;

import br.com.dmtec.forum.dto.RoomDTO;

public class InsertRoomResponse {

	private RoomDTO room;

	private boolean sucess;

	public RoomDTO getRoom() {
		return room;
	}

	public void setRoom(RoomDTO room) {
		this.room = room;
	}

	public boolean isSucess() {
		return sucess;
	}

	public void setSucess(boolean sucess) {
		this.sucess = sucess;
	}

}
