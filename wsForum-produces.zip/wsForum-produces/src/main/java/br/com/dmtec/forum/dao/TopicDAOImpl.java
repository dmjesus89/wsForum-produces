package br.com.dmtec.forum.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.dmtec.forum.dto.TopicDTO;

public class TopicDAOImpl {

	static List<TopicDTO> topicList = new ArrayList<TopicDTO>();

	static {
		if (topicList.isEmpty()) {

			TopicDTO t1 = new TopicDTO(1, "Solicita��es de Acesso Funcion�rio Novo");
			TopicDTO t2 = new TopicDTO(2, "Solicita��o GMUD Homologa��o");

			topicList.add(t1);
			topicList.add(t2);

		}

	}

	public static boolean insertTopic(TopicDTO topicDTO) {
		topicList.add(topicDTO);
		return true;
	}

	public static TopicDTO getTopicById(long id) {
		for (TopicDTO product : topicList) {
			if (product.getId() == id) {
				return product;
			}
		}
		return null;
	}

	public static List<TopicDTO> getTopicByCriteria(TopicDTO topic) {
		List<TopicDTO> topicListCriteria = new ArrayList<TopicDTO>();
		for (TopicDTO topicEach : topicList) {
			if (topicEach.getDescription().contains(topic.getDescription().toLowerCase())) {
				topicListCriteria.add(topicEach);
				return topicListCriteria;
			}
		}
		return topicListCriteria;
	}

	public static List<TopicDTO> getAllTopic() {
		return topicList;
	}

}
