package br.com.dmtec.forum.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PersonDTO")
public class PersonDTO {

	@XmlElement(name = "id", required = true)
	private long id;

	@XmlElement(name = "name", required = true)
	private String name;

	@XmlElement(name = "gender", required = true)
	private String gender;

	@XmlElement(name = "dtBorn", required = true)
	@XmlSchemaType(name = "date")
	private Date dtBorn;

	@XmlElement(name = "nationality", required = true)
	private NationalityDTO nationality;

	@XmlElement(name = "address", required = true)
	private AddressDTO address;

	@XmlElement(name = "phone", required = true)
	private PhoneDTO phone;

	@XmlElement(name = "numberPassport", required = true)
	private String numberPassport;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDtBorn() {
		return dtBorn;
	}

	public void setDtBorn(Date dtBorn) {
		this.dtBorn = dtBorn;
	}

	public NationalityDTO getNationality() {
		return nationality;
	}

	public void setNationality(NationalityDTO nationality) {
		this.nationality = nationality;
	}

	public AddressDTO getAddress() {
		return address;
	}

	public void setAddress(AddressDTO address) {
		this.address = address;
	}

	public PhoneDTO getPhone() {
		return phone;
	}

	public void setPhone(PhoneDTO phone) {
		this.phone = phone;
	}

	public String getNumberPassport() {
		return numberPassport;
	}

	public void setNumberPassport(String numberPassport) {
		this.numberPassport = numberPassport;
	}

}
