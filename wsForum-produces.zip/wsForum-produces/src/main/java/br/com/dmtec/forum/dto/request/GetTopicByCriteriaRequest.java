package br.com.dmtec.forum.dto.request;

import br.com.dmtec.forum.dto.TopicDTO;

public class GetTopicByCriteriaRequest {

	private TopicDTO topic;

	public TopicDTO getTopic() {
		return this.topic;
	}

	public void setTopic(TopicDTO topic) {
		this.topic = topic;
	}

}
