package br.com.dmtec.forum.dto.request;

import java.io.Serializable;

import br.com.dmtec.forum.dto.TopicDTO;

public class InsertTopicRequest implements Serializable {

	private final static long serialVersionUID = 1L;

	private TopicDTO topic;

	public TopicDTO getTopic() {
		return topic;
	}

	public void setTopic(TopicDTO topic) {
		this.topic = topic;
	}

}
