package br.com.dmtec.forum.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.dmtec.forum.dto.UserDTO;

public class UserDAOImpl {

	private static List<UserDTO> users = new ArrayList<>();

	public static boolean insert(UserDTO user) {
		users.add(user);
		return true;
	}

	public static UserDTO getById(long id) {
		for (UserDTO user : users) {
			if (user.getId() == id) {
				return user;
			}
		}
		return null;
	}

	public static UserDTO getByEmail(String email) {
		for (UserDTO user : users) {
			if (user.getEmail().equalsIgnoreCase(email)) {
				return user;
			}
		}
		return null;
	}

	public static void active(String email) {
		for (UserDTO user : users) {
			if (user.getEmail().equalsIgnoreCase(email)) {
				user.setActive(true);
			}
		}

	}

}
