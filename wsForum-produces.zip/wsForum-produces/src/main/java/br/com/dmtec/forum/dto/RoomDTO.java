package br.com.dmtec.forum.dto;

public class RoomDTO {

}
