package br.com.dmtec.forum.exceptions;

public class ErrosConstants {

	public static final String ERROR_UNDEFINED_CODE = "@0000";
	public static final String ERROR_UNDEFINED_MSG = "Erro Desconhecido";

	public static final String ERROR_USER_NOT_FOUND_CODE = "@0001";
	public static final String ERROR_USER_NOT_FOUND_MSG = "Usu�rio N�o encontrado";

	public static final String ERROR_USER_DEACTIVATE_CODE = "@0002";
	public static final String ERROR_USER_DEACTIVATE_MSG = "Usu�rio desativado, solicite a reativa��o";

	public static final String ERROR_USER_ACTIVATE_CODE = "@0003";
	public static final String ERROR_USER_ACTIVATE_MSG = "Usu�rio j� est� ativo";

	public static final String ERROR_GENERATE_PASSWORD_CODE = "@0004";
	public static final String ERROR_GENERATE_PASSWORD_MSG = "N�o foi possivel gerar a senha";

	public static final String ERROR_EMAIL_EXIST_CODE = "@0005";
	public static final String ERROR_EMAIL_EXIST_MSG = "J� existe esse email cadastrado.";

	public static final String ERROR_CREATE_PASSWORD_CODE = "@0006";
	public static final String ERROR_CREATE_PASSWORD_MSG = "Senha deve ter no m�nimo 4 caracteres, pelo menos 1 letra e 1 n�mero";

}
