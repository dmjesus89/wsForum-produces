package br.com.dmtec.forum.dto.response;

import br.com.dmtec.forum.dto.TopicDTO;

public class GetTopicByIdResponse {

	private TopicDTO topicDTO;

	public void setTopic(TopicDTO topicDTO) {
		this.topicDTO = topicDTO;

	}

	public TopicDTO getTopicDTO() {
		return topicDTO;
	}

}
