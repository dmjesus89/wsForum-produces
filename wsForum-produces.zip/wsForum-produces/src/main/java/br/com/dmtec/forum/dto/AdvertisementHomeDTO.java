package br.com.dmtec.forum.dto;

import java.sql.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "AdvertisementHomeDTO")
@XmlType(name = "AdvertisementHomeDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class AdvertisementHomeDTO {

	@XmlElement(name = "id", required = true)
	private int id;

	@XmlElement(name = "home", required = true)
	private HomeDTO home;

	@XmlElement(name = "available")
	private boolean available;

	@XmlElement(name = "price", required = true)
	private double price;

	@XmlElement(name = "pictures", required = true)
	private String pictures;

	@XmlElement(name = "dtCadastro", required = true)
	private Date dtCadastro;

	@XmlElement(name = "user")
	private UserDTO user;

	@XmlElementWrapper(name = "phones")
	@XmlElement(name = "phone")
	private List<PhoneDTO> phones;

	@XmlTransient
	private boolean active;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public HomeDTO getHome() {
		return home;
	}

	public void setHome(HomeDTO home) {
		this.home = home;
	}

	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getPictures() {
		return pictures;
	}

	public void setPictures(String pictures) {
		this.pictures = pictures;
	}

	public Date getDtCadastro() {
		return dtCadastro;
	}

	public void setDtCadastro(Date dtCadastro) {
		this.dtCadastro = dtCadastro;
	}

	public UserDTO getUser() {
		return user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

	public List<PhoneDTO> getPhones() {
		return phones;
	}

	public void setPhones(List<PhoneDTO> phones) {
		this.phones = phones;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

}
