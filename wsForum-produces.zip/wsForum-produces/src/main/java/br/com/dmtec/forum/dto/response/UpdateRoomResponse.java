package br.com.dmtec.forum.dto.response;

public class UpdateRoomResponse {

	private boolean sucess;

	public boolean isSucess() {
		return sucess;
	}

	public void setSucess(boolean sucess) {
		this.sucess = sucess;
	}

}
