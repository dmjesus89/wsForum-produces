package br.com.dmtec.forum.dto;

import java.sql.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "UserDTO")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserDTO")
public class UserDTO extends PersonDTO {

	@XmlElement(name = "id", required = true)
	private long id;

	@XmlElement(name = "email", required = true, nillable = true)
	private String email;

	@XmlElement(required = true, nillable = false)
	private String password;

	@XmlElement(name = "escort", required = true, nillable = false)
	private boolean escort;

	@XmlElement(name = "dtCadastro")
	private Date dtCadastro;

	@XmlElement(name = "active")
	private boolean active;
	
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isEscort() {
		return escort;
	}

	public void setEscort(boolean escort) {
		this.escort = escort;
	}

	public Date getDtCadastro() {
		return dtCadastro;
	}

	public void setDtCadastro(Date dtCadastro) {
		this.dtCadastro = dtCadastro;
	}

	public boolean getActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

}
