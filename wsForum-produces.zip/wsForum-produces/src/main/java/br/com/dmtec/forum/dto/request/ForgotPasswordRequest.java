package br.com.dmtec.forum.dto.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "ForgotPasswordRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class ForgotPasswordRequest {

	@XmlElement(name = "email", required = true)
	private String email;

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
