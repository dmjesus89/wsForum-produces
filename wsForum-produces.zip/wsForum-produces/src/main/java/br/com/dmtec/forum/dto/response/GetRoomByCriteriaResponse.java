package br.com.dmtec.forum.dto.response;

import java.util.List;

import br.com.dmtec.forum.dto.RoomDTO;

public class GetRoomByCriteriaResponse {

	private boolean sucess;
	private List<RoomDTO> rooms;

	public boolean isSucess() {
		return sucess;
	}

	public void setSucess(boolean sucess) {
		this.sucess = sucess;
	}

	public List<RoomDTO> getRooms() {
		return rooms;
	}

	public void setRooms(List<RoomDTO> rooms) {
		this.rooms = rooms;
	}

}
