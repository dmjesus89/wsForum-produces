package br.com.dmtec.forum.exceptions;

import javax.xml.ws.WebFault;

@WebFault(name = "ServiceException")
public class ServiceException extends Exception {

	private static final long serialVersionUID = 1L;

	public ServiceException() {
	}

	private ServiceFault serviceFault;

	public ServiceException(String message) {
		super(message);
	}

	public ServiceException(String message, ServiceFault serviceFault) {
		super(message);
		this.serviceFault = serviceFault;
	}

	public ServiceException(String message, Throwable e, ServiceFault serviceFault) {
		super(message, e);
		this.serviceFault = serviceFault;
	}

	public ServiceFault getServiceFault() {
		return serviceFault;
	}

	public void setServiceFault(ServiceFault serviceFault) {
		this.serviceFault = serviceFault;
	}

	public ServiceException(ServiceFault serviceFault) {
		super(serviceFault.getDescription());
		this.serviceFault = serviceFault;
	}

	public ServiceException(String message, ServiceFault serviceFaultInfo, Throwable cause) {
		super(message, cause);
		this.serviceFault = serviceFaultInfo;
	}

	public ServiceException(String code, String message) {
		super(message);
		this.serviceFault = new ServiceFault();
		this.serviceFault.setDescription(message);
		this.serviceFault.setCode(code);
	}

	public ServiceException(Throwable cause) {
		super(cause);
	}

	public ServiceException(String message, Throwable cause) {
		super(message, cause);
	}

}