package br.com.dmtec.forum.dto.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

import br.com.dmtec.forum.dto.AdvertisementHomeDTO;

@XmlType(name = "GetAllAdvertisementHomeResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class GetAllAdvertisementHomeResponse {

	@XmlElementWrapper(name = "listAdvertisementHome")
	@XmlElement(name = "advertisementHome")
	private List<AdvertisementHomeDTO> listAdvertisementHome;

	@XmlElement(name = "success", required = true)
	private boolean success;

	public List<AdvertisementHomeDTO> getListAdvertisementHome() {
		return listAdvertisementHome;
	}

	public void setListAdvertisementHome(List<AdvertisementHomeDTO> listAdvertisementHome) {
		this.listAdvertisementHome = listAdvertisementHome;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

}
