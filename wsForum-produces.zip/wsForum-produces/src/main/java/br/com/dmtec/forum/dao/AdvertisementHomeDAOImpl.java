package br.com.dmtec.forum.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.dmtec.forum.dto.AdvertisementHomeDTO;

public class AdvertisementHomeDAOImpl {

	private static List<AdvertisementHomeDTO> advertisementHomes = new ArrayList<>();

	public static boolean insert(AdvertisementHomeDTO room) {
		advertisementHomes.add(room);
		return true;
	}

	public static AdvertisementHomeDTO getById(long id) {
		for (AdvertisementHomeDTO advertisementHomeEach : advertisementHomes) {
			if (advertisementHomeEach.getId() == id) {
				return advertisementHomeEach;
			}
		}
		return null;
	}

	public static List<AdvertisementHomeDTO> getAll() {
		return advertisementHomes;
	}

	public static boolean update(AdvertisementHomeDTO advertisementHome) {
		for (AdvertisementHomeDTO advertisementHomeEach : advertisementHomes) {
			if (advertisementHomeEach.getId() == advertisementHome.getId()) {
				advertisementHomeEach = advertisementHome;
			}
		}
		return true;
	}

	public static boolean delete(long id) {
		for (AdvertisementHomeDTO advertisementHomeEach : advertisementHomes) {
			if (advertisementHomeEach.getId() == id) {
				advertisementHomes.remove(id);
			}
		}
		return true;
	}

}
