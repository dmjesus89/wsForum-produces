package br.com.dmtec.forum.service;

import java.security.MessageDigest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.com.dmtec.forum.dao.UserDAOImpl;
import br.com.dmtec.forum.dto.UserDTO;

public class UserService {

	private static final String EXPRESSAO_REGULAR_SENHA_FORTE = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{4,}$";

	public static boolean insert(UserDTO user) throws Exception {

		if (getByEmail(user.getEmail()) != null) {
			throw new Exception("J� existe esse email cadastrado.");
		}

		if (!validatePassword(user.getPassword())) {
			throw new Exception("Senha deve ter no m�nimo 4 caracteres, pelo menos 1 letra e 1 n�mero");
		}

		criptPassword(user.getPassword());

		return UserDAOImpl.insert(user);
	}

	public static UserDTO getByEmail(String email) throws Exception {
		return UserDAOImpl.getByEmail(email);
	}

	public static UserDTO getById(long id) throws Exception {
		return UserDAOImpl.getById(id);
	}

	public static boolean login(String email, String password) throws Exception {
		UserDTO user = getByEmail(email);
		if (!user.getActive()) {
			throw new Exception("Usu�rio foi desativado");
		}
		password.equals(criptPassword(user.getPassword()));
		Pattern p = Pattern.compile(EXPRESSAO_REGULAR_SENHA_FORTE);
		Matcher m = p.matcher(password);
		return m.matches();
	}

	public static boolean forgotPassword(String email) throws Exception {
		UserDTO user = getByEmail(email);
		if (user == null) {
			throw new Exception("N�o existe esse email cadastrado.");
		}

		if (!user.getActive()) {
			throw new Exception("Usu�rio desativado, solicite a reativa��o");
		}

		return true;
	}

	public static boolean active(String email) throws Exception {
		UserDTO user = getByEmail(email);
		if (user == null) {
			throw new Exception("N�o existe esse email cadastrado.");
		}

		if (user.getActive()) {
			throw new Exception("Usu�rio j� est� ativo");
		}

		if (!user.getActive()) {
			UserDAOImpl.active(email);
		}

		return true;
	}

	private static String criptPassword(String password) throws Exception {
		try {
			MessageDigest algorithm = MessageDigest.getInstance("SHA-256");
			byte messageDigest[] = algorithm.digest(password.getBytes("UTF-8"));

			StringBuilder hexString = new StringBuilder();
			for (byte b : messageDigest) {
				hexString.append(String.format("%02X", 0xFF & b));
			}

			System.out.println(hexString.toString());

			return hexString.toString();
		} catch (Exception e) {
			throw new Exception("N�o foi possivel gerar a senha");
		}

	}

	private static boolean validatePassword(final String password) throws Exception {
		Pattern p = Pattern.compile(EXPRESSAO_REGULAR_SENHA_FORTE);
		Matcher m = p.matcher(password);
		return m.matches();
	}

}
