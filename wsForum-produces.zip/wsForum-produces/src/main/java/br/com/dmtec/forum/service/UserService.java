package br.com.dmtec.forum.service;

import java.security.MessageDigest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.com.dmtec.forum.dao.UserDAOImpl;
import br.com.dmtec.forum.dto.UserDTO;
import br.com.dmtec.forum.exceptions.ServiceFault;
import br.com.dmtec.forum.exceptions.ErrosConstants;
import br.com.dmtec.forum.exceptions.ServiceException;

public class UserService {

	private static final String EXPRESSAO_REGULAR_SENHA_FORTE = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{4,}$";

	public static boolean insert(UserDTO user) throws ServiceException {

		if (getByEmail(user.getEmail()) != null) {
			throw new ServiceException("ERROR",
					new ServiceFault(ErrosConstants.ERROR_EMAIL_EXIST_CODE, ErrosConstants.ERROR_EMAIL_EXIST_MSG));
		}

		if (!validatePassword(user.getPassword())) {
			throw new ServiceException("ERROR", new ServiceFault(ErrosConstants.ERROR_CREATE_PASSWORD_CODE,
					ErrosConstants.ERROR_CREATE_PASSWORD_MSG));
		}

		criptPassword(user.getPassword());

		return UserDAOImpl.insert(user);
	}

	public static UserDTO getByEmail(String email) throws ServiceException {
		UserDTO user = UserDAOImpl.getByEmail(email);

		return user;
	}

	public static UserDTO getById(long id) throws ServiceException {
		return UserDAOImpl.getById(id);
	}

	public static boolean login(String email, String password) throws ServiceException {
		UserDTO user = getByEmail(email);

		if (user == null) {
			throw new ServiceException("ERROR", new ServiceFault(ErrosConstants.ERROR_USER_NOT_FOUND_CODE,
					ErrosConstants.ERROR_USER_NOT_FOUND_MSG));
		}

		if (!user.getActive()) {
			throw new ServiceException("ERROR", new ServiceFault(ErrosConstants.ERROR_USER_DEACTIVATE_CODE,
					ErrosConstants.ERROR_USER_DEACTIVATE_MSG));
		}
		password.equals(criptPassword(user.getPassword()));
		Pattern p = Pattern.compile(EXPRESSAO_REGULAR_SENHA_FORTE);
		Matcher m = p.matcher(password);
		return m.matches();
	}

	public static boolean forgotPassword(String email) throws ServiceException {
		UserDTO user = getByEmail(email);

		if (user == null) {
			throw new ServiceException("ERROR", new ServiceFault(ErrosConstants.ERROR_USER_NOT_FOUND_CODE,
					ErrosConstants.ERROR_USER_NOT_FOUND_MSG));
		}

		if (!user.getActive()) {
			throw new ServiceException("ERROR", new ServiceFault(ErrosConstants.ERROR_USER_DEACTIVATE_CODE,
					ErrosConstants.ERROR_USER_DEACTIVATE_MSG));
		}

		return true;
	}

	public static boolean activate(String email) throws ServiceException {
		UserDTO user = getByEmail(email);

		if (user.getActive()) {
			throw new ServiceException("ERROR",
					new ServiceFault(ErrosConstants.ERROR_USER_ACTIVATE_CODE, ErrosConstants.ERROR_USER_ACTIVATE_MSG));
		}

		if (!user.getActive()) {
			UserDAOImpl.activate(email);
		}

		return true;
	}

	private static String criptPassword(String password) throws ServiceException {
		try {
			MessageDigest algorithm = MessageDigest.getInstance("SHA-256");
			byte messageDigest[] = algorithm.digest(password.getBytes("UTF-8"));

			StringBuilder hexString = new StringBuilder();

			for (byte b : messageDigest) {
				hexString.append(String.format("%02X", 0xFF & b));
			}

			return hexString.toString();

		} catch (Exception e) {
			throw new ServiceException("ERROR", new ServiceFault(ErrosConstants.ERROR_GENERATE_PASSWORD_CODE,
					ErrosConstants.ERROR_GENERATE_PASSWORD_MSG));
		}

	}

	private static boolean validatePassword(final String password) throws ServiceException {
		Pattern p = Pattern.compile(EXPRESSAO_REGULAR_SENHA_FORTE);
		Matcher m = p.matcher(password);
		return m.matches();
	}

}
