package br.com.dmtec.forum.ws;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import javax.jws.soap.SOAPBinding.Use;

import br.com.dmtec.forum.dto.request.DeleteRoomRequest;
import br.com.dmtec.forum.dto.request.GetRoomByCriteriaRequest;
import br.com.dmtec.forum.dto.request.GetRoomByIdRequest;
import br.com.dmtec.forum.dto.request.InsertRoomRequest;
import br.com.dmtec.forum.dto.request.UpdateRoomRequest;
import br.com.dmtec.forum.dto.response.DeleteRoomResponse;
import br.com.dmtec.forum.dto.response.GetAllRoomResponse;
import br.com.dmtec.forum.dto.response.GetRoomByCriteriaResponse;
import br.com.dmtec.forum.dto.response.GetRoomByIdResponse;
import br.com.dmtec.forum.dto.response.InsertRoomResponse;
import br.com.dmtec.forum.dto.response.UpdateRoomResponse;

@WebService(name = "roomWS")
@SOAPBinding(style = Style.RPC, use = Use.LITERAL)
public interface RoomWS {

	@WebMethod(operationName = "insertRoom")
	@WebResult(name = "insertRoomResponse")
	public InsertRoomResponse insertRoom(@WebParam(name = "insertRoomRequest") InsertRoomRequest insertRoomRequest);

	@WebMethod(operationName = "getRoomById")
	@WebResult(name = "getRoomByIdResponse")
	public GetRoomByIdResponse getRoomById(
			@WebParam(name = "getRoomByIdRequest") GetRoomByIdRequest getRoomByIdRequest);

	@WebMethod(operationName = "getRoomByCriteria")
	@WebResult(name = "getRoomByCriteriaResponse")
	public GetRoomByCriteriaResponse getRoomByCriteria(
			@WebParam(name = "getRoomByCriteriaRequest") GetRoomByCriteriaRequest getRoomByCriteriaRequest);

	@WebMethod(operationName = "getAllRoom")
	@WebResult(name = "getAllRoomResponse")
	public GetAllRoomResponse getAllRoom();
	
	@WebMethod(operationName = "updateRoom")
	@WebResult(name = "updateRoomResponse")
	public UpdateRoomResponse updateRoom(
			@WebParam(name = "updateRoomRequest") UpdateRoomRequest updateRoomRequest);
	
	@WebMethod(operationName = "deleteRoom")
	@WebResult(name = "deleteRoomResponse")
	public DeleteRoomResponse deleteRoom(
			@WebParam(name = "deleteRoomRequest") DeleteRoomRequest deleteRoomRequest);

}
