package br.com.dmtec.forum.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "AddressDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class AddressDTO {

	@XmlElement(name = "id", required = true)
	private long id;

	@XmlElement(name = "number", required = true)
	private int number;

	@XmlElement(name = "nmStreet", required = true)
	private String nmStreet;

	@XmlElement(name = "nmNeighborhood", required = true)
	private String nmNeighborhood;

	@XmlElement(name = "city", required = true)
	private CityDTO city;

	@XmlElement(name = "state", required = true)
	private StateDTO state;

	@XmlElement(name = "country", required = true)
	private CountryDTO country;

	@XmlElement(name = "reference")
	private String reference;

	@XmlElement(name = "postcode", required = true)
	private String postcode;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getNmStreet() {
		return nmStreet;
	}

	public void setNmStreet(String nmStreet) {
		this.nmStreet = nmStreet;
	}

	public String getNmNeighborhood() {
		return nmNeighborhood;
	}

	public void setNmNeighborhood(String nmNeighborhood) {
		this.nmNeighborhood = nmNeighborhood;
	}

	public CityDTO getCity() {
		return city;
	}

	public void setCity(CityDTO city) {
		this.city = city;
	}

	public StateDTO getState() {
		return state;
	}

	public void setState(StateDTO state) {
		this.state = state;
	}

	public CountryDTO getCountry() {
		return country;
	}

	public void setCountry(CountryDTO country) {
		this.country = country;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

}
