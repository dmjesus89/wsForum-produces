package br.com.dmtec.forum.dto.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import br.com.dmtec.forum.dto.AdvertisementHomeDTO;

@XmlType(name = "GetAdvertisementHomeByCriteriaRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class GetAdvertisementHomeByCriteriaRequest {

	@XmlElement(name = "advertisementHomeDTO", required = true)
	private AdvertisementHomeDTO advertisementHomeDTO;

	public AdvertisementHomeDTO getAdvertisementHomeDTO() {
		return advertisementHomeDTO;
	}

	public void setAdvertisementHomeDTO(AdvertisementHomeDTO advertisementHomeDTO) {
		this.advertisementHomeDTO = advertisementHomeDTO;
	}

}
