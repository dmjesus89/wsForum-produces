package br.com.dmtec.forum.dto.response;

import br.com.dmtec.forum.dto.RoomDTO;

public class GetRoomByIdResponse {

	private boolean sucess;
	private RoomDTO room;

	public boolean isSucess() {
		return sucess;
	}

	public void setSucess(boolean sucess) {
		this.sucess = sucess;
	}

	public RoomDTO getRooms() {
		return room;
	}

	public void setRoom(RoomDTO room) {
		this.room = room;
	}

}
