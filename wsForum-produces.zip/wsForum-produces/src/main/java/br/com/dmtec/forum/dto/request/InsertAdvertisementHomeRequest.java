package br.com.dmtec.forum.dto.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import br.com.dmtec.forum.dto.AdvertisementHomeDTO;

@XmlType(name = "InsertAdvertisementHomeRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class InsertAdvertisementHomeRequest {

	@XmlElement(name = "advertisementHome", required = true)
	private AdvertisementHomeDTO advertisementHome;

	public AdvertisementHomeDTO getAdvertisementHome() {
		return advertisementHome;
	}

	public void setAdvertisementHome(AdvertisementHomeDTO advertisementHome) {
		this.advertisementHome = advertisementHome;
	}

}
