package br.com.dmtec.forum.dto.response;

import java.io.Serializable;

import br.com.dmtec.forum.dto.TopicDTO;

public class InsertTopicResponse implements Serializable {

	private final static long serialVersionUID = 1L;
	private TopicDTO topic;
	private String errorMessage;
	private boolean sucess;

	public boolean isSucess() {
		return sucess;
	}

	public void setSucess(boolean sucess) {
		this.sucess = sucess;
	}

	public TopicDTO getTopic() {
		return topic;
	}

	public void setTopic(TopicDTO topic) {
		this.topic = topic;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
