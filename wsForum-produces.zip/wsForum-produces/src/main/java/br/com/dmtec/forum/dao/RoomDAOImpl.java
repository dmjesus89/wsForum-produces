package br.com.dmtec.forum.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.dmtec.forum.dto.RoomDTO;

public class RoomDAOImpl {

	public static boolean insertRoom(RoomDTO room) {
		return true;
	}

	public static RoomDTO getRoomById(long id) {
		return new RoomDTO();
	}

	public static List<RoomDTO> getRoomByCriteria(RoomDTO room) {
		return new ArrayList<RoomDTO>();
	}

	public static List<RoomDTO> getAllRoom() {
		return new ArrayList<RoomDTO>();
	}

	public static boolean updateRoom(RoomDTO room) {
		return true;
	}

	public static boolean deleteRoom(long id) {
		return true;
	}

}
