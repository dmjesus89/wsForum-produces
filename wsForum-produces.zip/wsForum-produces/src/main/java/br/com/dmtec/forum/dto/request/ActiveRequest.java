package br.com.dmtec.forum.dto.request;

public class ActiveRequest {

	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}

}
