package br.com.dmtec.forum.ws;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import javax.jws.soap.SOAPBinding.Use;

import br.com.dmtec.forum.dto.request.ActiveRequest;
import br.com.dmtec.forum.dto.request.ForgotPasswordRequest;
import br.com.dmtec.forum.dto.request.InsertUserRequest;
import br.com.dmtec.forum.dto.request.LoginUserRequest;
import br.com.dmtec.forum.dto.response.ActiveResponse;
import br.com.dmtec.forum.dto.response.ForgotPasswordResponse;
import br.com.dmtec.forum.dto.response.InsertUserResponse;
import br.com.dmtec.forum.dto.response.LoginUserResponse;

@WebService(name = "UserWS")
@SOAPBinding(style = Style.RPC, use = Use.LITERAL)
public interface UserWS {

	@WebMethod(operationName = "insert")
	@WebResult(name = "InsertUserResponse")
	public InsertUserResponse insert(@WebParam(name = "InsertUserRequest") InsertUserRequest insertUserRequest) throws Exception ;

	@WebMethod(operationName = "login")
	@WebResult(name = "LoginUserResponse")
	public LoginUserResponse login(@WebParam(name = "LoginUserRequest") LoginUserRequest loginUserRequest) throws Exception ;

	@WebMethod(operationName = "forgotPassword")
	@WebResult(name = "ForgotPasswordResponse")
	public ForgotPasswordResponse forgotPassword(
			@WebParam(name = "ForgotPasswordRequest") ForgotPasswordRequest forgotPasswordRequest) throws Exception ;

	@WebMethod(operationName = "active")
	@WebResult(name = "ActiveResponse")
	public ActiveResponse activate(@WebParam(name = "ActiveRequest") ActiveRequest activeRequest) throws Exception ;

}
