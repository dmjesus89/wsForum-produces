package br.com.dmtec.forum.dto.response;

import java.util.List;

import br.com.dmtec.forum.dto.AdvertisementHomeDTO;

public class GetAdvertisementHomeByCriteriaResponse {

	public void setListAdvertisementHome(List<AdvertisementHomeDTO> advertisementHome) {
		// TODO Auto-generated method stub
		
	}

	public void setSuccess(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
