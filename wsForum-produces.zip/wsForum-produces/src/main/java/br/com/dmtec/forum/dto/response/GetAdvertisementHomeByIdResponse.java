package br.com.dmtec.forum.dto.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import br.com.dmtec.forum.dto.AdvertisementHomeDTO;

@XmlType(name = "GetAdvertisementHomeByIdResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class GetAdvertisementHomeByIdResponse {

	@XmlElement(name = "advertisementHomeDTO", required = true)
	private AdvertisementHomeDTO advertisementHomeDTO;

	@XmlElement(name = "success", required = true)
	private boolean success;

	public AdvertisementHomeDTO getAdvertisementHomeDTO() {
		return advertisementHomeDTO;
	}

	public void setAdvertisementHomeDTO(AdvertisementHomeDTO advertisementHomeDTO) {
		this.advertisementHomeDTO = advertisementHomeDTO;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

}
