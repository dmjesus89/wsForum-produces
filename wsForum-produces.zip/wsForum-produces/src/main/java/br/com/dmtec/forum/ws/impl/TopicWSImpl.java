package br.com.dmtec.forum.ws.impl;

import javax.jws.WebService;

import br.com.dmtec.forum.dto.TopicDTO;
import br.com.dmtec.forum.dto.request.GetTopicByCriteriaRequest;
import br.com.dmtec.forum.dto.request.GetTopicByIdRequest;
import br.com.dmtec.forum.dto.request.InsertTopicRequest;
import br.com.dmtec.forum.dto.response.GetAllTopicResponse;
import br.com.dmtec.forum.dto.response.GetTopicByCriteriaResponse;
import br.com.dmtec.forum.dto.response.GetTopicByIdResponse;
import br.com.dmtec.forum.dto.response.InsertTopicResponse;
import br.com.dmtec.forum.service.TopicService;
import br.com.dmtec.forum.ws.TopicWS;

@WebService(endpointInterface = "br.com.dmtec.forum.ws.TopicWS", serviceName = "topicWS")
public class TopicWSImpl implements TopicWS {

	@Override
	public InsertTopicResponse insertTopic(InsertTopicRequest insertTopicRequest) {
		InsertTopicResponse response = new InsertTopicResponse();
		try {
			TopicService.insertTopic(insertTopicRequest.getTopic());
			response.setSucess(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public GetTopicByIdResponse getTopicById(GetTopicByIdRequest getTopicByIdRequest) {
		TopicDTO topic = getTopicByIdRequest.getTopic();
		GetTopicByIdResponse response = new GetTopicByIdResponse();
		response.setTopic(TopicService.getTopicById(topic.getId()));
		return response;
	}

	public GetTopicByCriteriaResponse getTopicByCriteria(GetTopicByCriteriaRequest getTopicByCriteriaRequest) {
		TopicDTO topic = getTopicByCriteriaRequest.getTopic();
		GetTopicByCriteriaResponse response = new GetTopicByCriteriaResponse();
		response.setTopic(TopicService.getTopicById(topic.getId()));
		return response;
	}

	@Override
	public GetAllTopicResponse getAllTopic() {
		GetAllTopicResponse response = new GetAllTopicResponse();
		response.setTopics(TopicService.getAllTopic());
		return response;
	}

}
