package br.com.dmtec.forum.service;

import java.util.List;

import br.com.dmtec.forum.dao.AdvertisementHomeDAOImpl;
import br.com.dmtec.forum.dto.AdvertisementHomeDTO;
import br.com.dmtec.forum.dto.UserDTO;

public class AdvertisementHomeService {

	public static boolean insert(AdvertisementHomeDTO advertisementHome) throws Exception {
		long idUser = advertisementHome.getUser().getId();
		UserDTO user = UserService.getById(idUser);
		if (user == null) {
			throw new Exception("User n�o encontrado");
		}
		return AdvertisementHomeDAOImpl.insert(advertisementHome);
	}

	public static AdvertisementHomeDTO getById(long id) {
		return AdvertisementHomeDAOImpl.getById(id);
	}

	public static List<AdvertisementHomeDTO> getAll() {
		return AdvertisementHomeDAOImpl.getAll();
	}

	public static boolean update(AdvertisementHomeDTO advertisementHome) {
		return AdvertisementHomeDAOImpl.update(advertisementHome);
	}

	public static boolean delete(long id) {
		AdvertisementHomeDTO advertisementHome = getById(id);
		advertisementHome.setActive(false);
		return AdvertisementHomeDAOImpl.update(advertisementHome);
	}

}
