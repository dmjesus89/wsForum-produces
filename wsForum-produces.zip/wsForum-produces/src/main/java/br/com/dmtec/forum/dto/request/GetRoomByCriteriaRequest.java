package br.com.dmtec.forum.dto.request;

import br.com.dmtec.forum.dto.RoomDTO;

public class GetRoomByCriteriaRequest {

	private RoomDTO room;

	public RoomDTO getRoom() {
		return room;
	}

	public void setRoom(RoomDTO room) {
		this.room = room;
	}

}
