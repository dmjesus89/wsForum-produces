package br.com.dmtec.forum.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "HomeDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class HomeDTO {

	@XmlElement(name = "id", required = true)
	private int id;

	@XmlElement(name = "description", required = true)
	private String description;

	@XmlElement(name = "address", required = true)
	private AddressDTO address;

	@XmlElement(name = "numberRooms", required = true)
	private int numberRooms;

	@XmlElement(name = "numberRoomsAvailible", required = true)
	private int numberRoomsAvailible;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public AddressDTO getAddress() {
		return address;
	}

	public void setAddress(AddressDTO address) {
		this.address = address;
	}

	public int getNumberRooms() {
		return numberRooms;
	}

	public void setNumberRooms(int numberRooms) {
		this.numberRooms = numberRooms;
	}

	public int getNumberRoomsAvailible() {
		return numberRoomsAvailible;
	}

	public void setNumberRoomsAvailible(int numberRoomsAvailible) {
		this.numberRoomsAvailible = numberRoomsAvailible;
	}

}
