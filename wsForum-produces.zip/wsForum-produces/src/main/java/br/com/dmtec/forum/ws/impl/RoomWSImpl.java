package br.com.dmtec.forum.ws.impl;

import java.util.List;

import javax.jws.WebService;

import br.com.dmtec.forum.dto.RoomDTO;
import br.com.dmtec.forum.dto.request.DeleteRoomRequest;
import br.com.dmtec.forum.dto.request.GetRoomByCriteriaRequest;
import br.com.dmtec.forum.dto.request.GetRoomByIdRequest;
import br.com.dmtec.forum.dto.request.InsertRoomRequest;
import br.com.dmtec.forum.dto.request.UpdateRoomRequest;
import br.com.dmtec.forum.dto.response.DeleteRoomResponse;
import br.com.dmtec.forum.dto.response.GetAllRoomResponse;
import br.com.dmtec.forum.dto.response.GetRoomByCriteriaResponse;
import br.com.dmtec.forum.dto.response.GetRoomByIdResponse;
import br.com.dmtec.forum.dto.response.InsertRoomResponse;
import br.com.dmtec.forum.dto.response.UpdateRoomResponse;
import br.com.dmtec.forum.service.RoomService;
import br.com.dmtec.forum.ws.RoomWS;

@WebService(endpointInterface = "br.com.dmtec.forum.ws.RoomWS", serviceName = "roomWS")
public class RoomWSImpl implements RoomWS {

	@Override
	public InsertRoomResponse insertRoom(InsertRoomRequest insertRoomRequest) {
		InsertRoomResponse response = new InsertRoomResponse();
		try {
			boolean success = RoomService.insertRoom(insertRoomRequest.getRoom());
			response.setSucess(success);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public GetRoomByIdResponse getRoomById(GetRoomByIdRequest getRoomByIdRequest) {
		GetRoomByIdResponse response = new GetRoomByIdResponse();
		try {
			RoomDTO room = RoomService.getRoomById(getRoomByIdRequest.getId());
			response.setRoom(room);
			response.setSucess(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public GetRoomByCriteriaResponse getRoomByCriteria(GetRoomByCriteriaRequest getRoomByCriteriaRequest) {
		GetRoomByCriteriaResponse response = new GetRoomByCriteriaResponse();
		try {
			List<RoomDTO> rooms = RoomService.getRoomByCriteria(getRoomByCriteriaRequest.getRoom());
			response.setRooms(rooms);
			response.setSucess(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public GetAllRoomResponse getAllRoom() {
		GetAllRoomResponse response = new GetAllRoomResponse();
		try {
			List<RoomDTO> rooms = RoomService.getAllRoom();
			response.setRooms(rooms);
			response.setSucess(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public UpdateRoomResponse updateRoom(UpdateRoomRequest updateRoomRequest) {
		UpdateRoomResponse response = new UpdateRoomResponse();
		try {
			boolean success = RoomService.updateRoom(updateRoomRequest.getRoom());
			response.setSucess(success);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public DeleteRoomResponse deleteRoom(DeleteRoomRequest deleteRoomRequest) {
		DeleteRoomResponse response = new DeleteRoomResponse();
		try {
			boolean success = RoomService.deleteRoom(deleteRoomRequest.getId());
			response.setSucess(success);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

}
