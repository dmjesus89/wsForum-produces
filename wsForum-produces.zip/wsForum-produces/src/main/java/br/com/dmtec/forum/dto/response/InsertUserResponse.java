package br.com.dmtec.forum.dto.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import br.com.dmtec.forum.dto.UserDTO;

@XmlType(name = "InsertUserResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class InsertUserResponse {

	@XmlElement(name = "userDTO", required = true)
	private UserDTO userDTO;

	@XmlElement(name = "success", required = true)
	private boolean success;

	public UserDTO getUserDTO() {
		return userDTO;
	}

	public void setUserDTO(UserDTO userDTO) {
		this.userDTO = userDTO;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

}
