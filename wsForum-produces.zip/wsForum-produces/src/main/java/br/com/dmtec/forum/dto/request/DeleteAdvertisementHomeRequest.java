package br.com.dmtec.forum.dto.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "DeleteAdvertisementHomeRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class DeleteAdvertisementHomeRequest {

	@XmlElement(name = "id", required = true)
	private long id;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

}
