package br.com.dmtec.forum.ws.impl;

import java.util.List;

import javax.jws.WebService;

import br.com.dmtec.forum.dto.AdvertisementHomeDTO;
import br.com.dmtec.forum.dto.request.DeleteAdvertisementHomeRequest;
import br.com.dmtec.forum.dto.request.GetAdvertisementHomeByCriteriaRequest;
import br.com.dmtec.forum.dto.request.GetAdvertisementHomeByIdRequest;
import br.com.dmtec.forum.dto.request.InsertAdvertisementHomeRequest;
import br.com.dmtec.forum.dto.request.UpdateAdvertisementHomeRequest;
import br.com.dmtec.forum.dto.response.DeleteAdvertisementHomeResponse;
import br.com.dmtec.forum.dto.response.GetAdvertisementHomeByCriteriaResponse;
import br.com.dmtec.forum.dto.response.GetAdvertisementHomeByIdResponse;
import br.com.dmtec.forum.dto.response.GetAllAdvertisementHomeResponse;
import br.com.dmtec.forum.dto.response.InsertAdvertisementHomeResponse;
import br.com.dmtec.forum.dto.response.UpdateAdvertisementHomeResponse;
import br.com.dmtec.forum.service.AdvertisementHomeService;
import br.com.dmtec.forum.ws.AdvertisementHomeWS;

@WebService(endpointInterface = "br.com.dmtec.forum.ws.AdvertisementHomeWS", serviceName = "AdvertisementHomeWS")
public class AdvertisementHomeWSImpl implements AdvertisementHomeWS {

	@Override
	public InsertAdvertisementHomeResponse insert(InsertAdvertisementHomeRequest insertAdvertisementHomeRequest) {
		InsertAdvertisementHomeResponse response = new InsertAdvertisementHomeResponse();
		try {
			response.setSuccess(AdvertisementHomeService.insert(insertAdvertisementHomeRequest.getAdvertisementHome()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public GetAdvertisementHomeByIdResponse getById(GetAdvertisementHomeByIdRequest getAdvertisementHomeByIdRequest) {
		GetAdvertisementHomeByIdResponse response = new GetAdvertisementHomeByIdResponse();
		try {
			AdvertisementHomeDTO advertisementHomeDTO = AdvertisementHomeService
					.getById(getAdvertisementHomeByIdRequest.getId());
			response.setAdvertisementHomeDTO(advertisementHomeDTO);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public GetAllAdvertisementHomeResponse getAllActive() {
		GetAllAdvertisementHomeResponse response = new GetAllAdvertisementHomeResponse();
		try {
			List<AdvertisementHomeDTO> advertisementHome = AdvertisementHomeService.getAllActive();
			response.setListAdvertisementHome(advertisementHome);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public GetAdvertisementHomeByCriteriaResponse getByCriteria(
			GetAdvertisementHomeByCriteriaRequest getAdvertisementHomeByCriteriaRequest) {
		GetAdvertisementHomeByCriteriaResponse response = new GetAdvertisementHomeByCriteriaResponse();
		try {
			List<AdvertisementHomeDTO> advertisementHome = AdvertisementHomeService.getByCriteria();
			response.setListAdvertisementHome(advertisementHome);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public UpdateAdvertisementHomeResponse update(UpdateAdvertisementHomeRequest updateAdvertisementHomeRequest) {
		UpdateAdvertisementHomeResponse response = new UpdateAdvertisementHomeResponse();
		try {
			boolean success = AdvertisementHomeService.update(updateAdvertisementHomeRequest.getAdvertisementHomeDTO());
			response.setSuccess(success);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public DeleteAdvertisementHomeResponse delete(DeleteAdvertisementHomeRequest deleteAdvertisementHomeRequest) {
		DeleteAdvertisementHomeResponse response = new DeleteAdvertisementHomeResponse();
		try {
			boolean success = AdvertisementHomeService.delete(deleteAdvertisementHomeRequest.getId());
			response.setSuccess(success);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

}
