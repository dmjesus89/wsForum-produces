package br.com.dmtec.forum.ws.impl;

import javax.jws.WebService;

import br.com.dmtec.forum.dto.request.ActiveRequest;
import br.com.dmtec.forum.dto.request.ForgotPasswordRequest;
import br.com.dmtec.forum.dto.request.InsertUserRequest;
import br.com.dmtec.forum.dto.request.LoginUserRequest;
import br.com.dmtec.forum.dto.response.ActiveResponse;
import br.com.dmtec.forum.dto.response.ForgotPasswordResponse;
import br.com.dmtec.forum.dto.response.InsertUserResponse;
import br.com.dmtec.forum.dto.response.LoginUserResponse;
import br.com.dmtec.forum.service.UserService;
import br.com.dmtec.forum.ws.UserWS;

@WebService(endpointInterface = "br.com.dmtec.forum.ws.UserWS", serviceName = "UserWS")
public class UserWSImpl implements UserWS {

	@Override
	public InsertUserResponse insert(InsertUserRequest insertUserRequest) throws Exception {
		InsertUserResponse response = new InsertUserResponse();
		try {
			response.setSuccess(UserService.insert(insertUserRequest.getUser()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public LoginUserResponse login(LoginUserRequest loginUserRequest) throws Exception {
		LoginUserResponse response = new LoginUserResponse();
		try {
			boolean success = UserService.login(loginUserRequest.getUser().getEmail(),
					loginUserRequest.getUser().getPassword());
			response.setSuccess(success);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public ForgotPasswordResponse forgotPassword(ForgotPasswordRequest forgotPasswordRequest) throws Exception {
		ForgotPasswordResponse response = new ForgotPasswordResponse();
		try {
			boolean success = UserService.forgotPassword(forgotPasswordRequest.getUser().getEmail());
			response.setSuccess(success);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public ActiveResponse activate(ActiveRequest activeRequest) throws Exception {
		ActiveResponse response = new ActiveResponse();
		try {
			boolean success = UserService.activate(activeRequest.getUser().getEmail());
			response.setSuccess(success);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

}
