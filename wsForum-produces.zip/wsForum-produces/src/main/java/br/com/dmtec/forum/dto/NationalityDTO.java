package br.com.dmtec.forum.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "NationalityDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class NationalityDTO {

	@XmlElement(name = "id", required = true)
	private int id;

	@XmlElement(name = "name", required = true)
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
