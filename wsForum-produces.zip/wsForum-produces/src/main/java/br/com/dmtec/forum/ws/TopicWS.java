package br.com.dmtec.forum.ws;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import javax.jws.soap.SOAPBinding.Use;

import br.com.dmtec.forum.dto.request.GetTopicByCriteriaRequest;
import br.com.dmtec.forum.dto.request.GetTopicByIdRequest;
import br.com.dmtec.forum.dto.request.InsertTopicRequest;
import br.com.dmtec.forum.dto.response.GetAllTopicResponse;
import br.com.dmtec.forum.dto.response.GetTopicByCriteriaResponse;
import br.com.dmtec.forum.dto.response.GetTopicByIdResponse;
import br.com.dmtec.forum.dto.response.InsertTopicResponse;

@WebService(name = "topicWS")
@SOAPBinding(style = Style.RPC, use = Use.LITERAL)
public interface TopicWS {

	@WebMethod(operationName = "insertTopic")
	public InsertTopicResponse insertTopic(
			@WebParam(name = "insertTopicRequest") InsertTopicRequest insertTopicRequest);

	@WebMethod(operationName = "getTopicById")
	public GetTopicByIdResponse getTopicById(
			@WebParam(name = "getTopicByIdRequest") GetTopicByIdRequest getTopicByIdRequest);

	@WebMethod(operationName = "getTopicByCriteria")
	public GetTopicByCriteriaResponse getTopicByCriteria(
			@WebParam(name = "getTopicByCriteriaRequest") GetTopicByCriteriaRequest getTopicByCriteriaRequest);

	@WebMethod(operationName = "getAllTopic")
	public GetAllTopicResponse getAllTopic();

}
