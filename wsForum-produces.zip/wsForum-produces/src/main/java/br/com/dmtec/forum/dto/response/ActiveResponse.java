package br.com.dmtec.forum.dto.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "ActiveResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class ActiveResponse {

	@XmlElement(name = "success", required = true)
	private boolean success;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

}
