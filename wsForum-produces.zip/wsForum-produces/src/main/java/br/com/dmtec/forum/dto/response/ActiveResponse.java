package br.com.dmtec.forum.dto.response;

public class ActiveResponse {

	public void setSuccess(boolean success) {
		// TODO Auto-generated method stub
		
	}

}
