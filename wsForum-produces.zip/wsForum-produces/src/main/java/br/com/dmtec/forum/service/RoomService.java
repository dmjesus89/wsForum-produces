package br.com.dmtec.forum.service;

import java.util.List;

import br.com.dmtec.forum.dao.RoomDAOImpl;
import br.com.dmtec.forum.dto.RoomDTO;

public class RoomService {

	public static boolean insertRoom(RoomDTO room) {
		return RoomDAOImpl.insertRoom(room);
	}

	public static RoomDTO getRoomById(long id) {
		return RoomDAOImpl.getRoomById(id);
	}

	public static List<RoomDTO> getRoomByCriteria(RoomDTO room) {
		return RoomDAOImpl.getRoomByCriteria(room);
	}

	public static List<RoomDTO> getAllRoom() {
		return RoomDAOImpl.getAllRoom();
	}

	public static boolean updateRoom(RoomDTO room) {
		return RoomDAOImpl.updateRoom(room);
	}

	public static boolean deleteRoom(long id) {
		return RoomDAOImpl.deleteRoom(id);
	}

}
