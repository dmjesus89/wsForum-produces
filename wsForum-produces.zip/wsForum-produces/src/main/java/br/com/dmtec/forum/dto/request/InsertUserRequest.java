package br.com.dmtec.forum.dto.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import br.com.dmtec.forum.dto.UserDTO;

@XmlType(name = "InsertUserRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class InsertUserRequest {

	@XmlElement(name = "user", required = true)
	private UserDTO user;

	public UserDTO getUser() {
		return user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

}
