package br.com.dmtec.forum.dto.response;

import java.util.List;

import br.com.dmtec.forum.dto.TopicDTO;

public class GetAllTopicResponse {

	private List<TopicDTO> topics;

	public List<TopicDTO> getTopics() {
		return topics;
	}

	public void setTopics(List<TopicDTO> topics) {
		this.topics = topics;
	}

}
