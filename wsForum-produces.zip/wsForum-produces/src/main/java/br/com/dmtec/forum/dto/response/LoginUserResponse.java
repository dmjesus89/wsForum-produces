package br.com.dmtec.forum.dto.response;

public class LoginUserResponse {

	private boolean success;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

}
